import 'package:flutter/material.dart';
import 'about_page.dart';

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Global Recipe Book"),
        backgroundColor: Colors.orange,
      ),
      body: Column(
        children: [
          // Food Banner
          Image.network(
            "https://images.unsplash.com/photo-1490645935967-10de6ba17061",
            height: 200,
            width: double.infinity,
            fit: BoxFit.cover,
          ),

          SizedBox(height: 20),

          // Login Button
          ElevatedButton(
            onPressed: () {
              // Later you can connect login page
            },
            child: Text("Login"),
          ),

          SizedBox(height: 10),

          // Navigate to About Page
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AboutPage()),
              );
            },
            child: Text("About App"),
          ),
        ],
      ),
    );
  }
}
