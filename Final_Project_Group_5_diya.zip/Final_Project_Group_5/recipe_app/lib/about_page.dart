import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("About"), backgroundColor: Colors.orange),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Global Recipe Book",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),

            SizedBox(height: 10),

            Text(
              "This app helps users discover recipes from around the world. "
              "Users can search recipes, view instructions, and save favorites.",
            ),

            SizedBox(height: 20),

            Text(
              "Features:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            SizedBox(height: 10),

            Text("• Search recipes"),
            Text("• Save favorites"),
            Text("• Ingredient cart"),
            Text("• Cooking timer"),
          ],
        ),
      ),
    );
  }
}
