import 'package:flutter/material.dart';
import 'about_screen.dart';
import 'recipe_list_screen.dart';
import 'favorite_screen.dart';
import 'login_screen.dart'; // ✅ ADD THIS

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Global Recipe Book"),
        backgroundColor: Colors.orange,
        centerTitle: true,
      ),

      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Banner Image
          Image.network(
            "https://images.unsplash.com/photo-1490645935967-10de6ba17061",
            height: 200,
            width: double.infinity,
            fit: BoxFit.cover,
          ),

          SizedBox(height: 30),

          // VIEW RECIPES
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => RecipeListScreen()),
              );
            },
            child: Text("View Recipes 🍲"),
          ),

          SizedBox(height: 10),

          // FAVORITES
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => FavoriteScreen()),
              );
            },
            child: Text("My Favorites ❤️"),
          ),

          SizedBox(height: 10),

          // ABOUT
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AboutScreen()),
              );
            },
            child: Text("About App"),
          ),

          SizedBox(height: 20),

          // ✅ LOGIN BUTTON (IMPORTANT FOR YOUR TASK)
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => LoginScreen()),
              );
            },
            child: Text("Login 🔐"),
          ),
        ],
      ),
    );
  }
}
