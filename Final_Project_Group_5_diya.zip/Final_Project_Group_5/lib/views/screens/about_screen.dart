import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("About"), backgroundColor: Colors.orange),

      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Global Recipe Book",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),

            SizedBox(height: 10),

            Text("Discover recipes from around the world."),

            SizedBox(height: 20),

            Text("Features:", style: TextStyle(fontWeight: FontWeight.bold)),

            Text("• Search recipes"),
            Text("• Save favorites"),
            Text("• Ingredient cart"),
            Text("• Timer"),
          ],
        ),
      ),
    );
  }
}
