import 'package:flutter/material.dart';
import '../../controllers/favorite_controller.dart';

class RecipeDetailScreen extends StatefulWidget {
  final Map recipe;

  RecipeDetailScreen({required this.recipe});

  @override
  _RecipeDetailScreenState createState() => _RecipeDetailScreenState();
}

class _RecipeDetailScreenState extends State<RecipeDetailScreen> {
  bool isFav = false;

  @override
  void initState() {
    super.initState();
    isFav = FavoriteController.isFavorite(widget.recipe["id"]);
  }

  @override
  Widget build(BuildContext context) {
    var recipe = widget.recipe;

    return Scaffold(
      appBar: AppBar(
        title: Text(recipe["title"]),
        backgroundColor: Colors.orange,
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.network(recipe["image"]),

            Padding(
              padding: EdgeInsets.all(10),
              child: Text(recipe["title"], style: TextStyle(fontSize: 22)),
            ),

            Padding(
              padding: EdgeInsets.all(10),
              child: Text(recipe["summary"] ?? ""),
            ),

            // ❤️ FAVORITE BUTTON
            IconButton(
              icon: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: Colors.red,
              ),
              onPressed: () {
                setState(() {
                  if (isFav) {
                    FavoriteController.removeFavorite(recipe["id"]);
                  } else {
                    FavoriteController.addFavorite(recipe);
                  }
                  isFav = !isFav;
                });

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      isFav ? "Added to favorites" : "Removed from favorites",
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
