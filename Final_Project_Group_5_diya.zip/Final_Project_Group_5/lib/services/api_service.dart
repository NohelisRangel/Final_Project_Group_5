import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String apiKey = "9326de07e3f241bb841e3ba8244772df";

  Future<List<dynamic>> fetchRecipes() async {
    final url = Uri.parse(
      "https://api.spoonacular.com/recipes/random?number=10&apiKey=$apiKey",
    );

    final response = await http.get(url);

    if (response.statusCode == 200) {
      return json.decode(response.body)["recipes"];
    } else {
      throw Exception("Error");
    }
  }
}
